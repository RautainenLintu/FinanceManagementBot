This is a university project 

Telegram: @AssetsRegistrationBot

v.0.0.3